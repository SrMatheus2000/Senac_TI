import pessoa from "./pessoa"
import usuario from "./usuário"
import medico from "./médico"
import operador from "./operador"

medico.logar("Matheus", "123")