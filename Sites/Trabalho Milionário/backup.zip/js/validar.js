//https://codewithawa.com/posts/form-validation-with-javascript

// seleção de elementos
var username = document.forms["cadastroform"]["nome"];
var password = document.forms["cadastroform"]["senha"];
var sobrenome = document.forms["cadastroform"]["sobrenome"];
var cpf = document.forms["cadastroform"]["cpf"];
var rg = document.forms["cadastroform"]["rg"];
var nacionalidade = document.forms["cadastroform"]["nacionalidade"];
var nascimento = document.forms["cadastroform"]["nascimento"];
var civil = document.forms["cadastroform"]["civil"];
var input_sexo = document.forms["cadastroform"]["input_sexo"];
var estado = document.forms["cadastroform"]["estado"];
var rua = document.forms["cadastroform"]["rua"];
var numero = document.forms["cadastroform"]["numero"];
var bairro = document.forms["cadastroform"]["bairro"];
var municipio = document.forms["cadastroform"]["municipio"];
var cep = document.forms["cadastroform"]["cep"];
var telefone1 = document.forms["cadastroform"]["telefone1"];
var telefone2 = document.forms["cadastroform"]["telefone2"];
var email = document.forms["cadastroform"]["email"];
//seleção de campos de erro
var error_username = document.getElementById('');
var error_password = document.getElementById('');
var error_sobrenome = document.getElementById('');
var error_cpf = document.getElementById('');
var error_rg   = document.getElementById('');
var error_nacionalidade = document.getElementById('');
var error_nascimento = document.getElementById('');
var error_civil = document.getElementById('');
var error_input_sexo = document.getElementById('');
var error_estado = document.getElementById('');
var error_rua = document.getElementById('');
var error_numero = document.getElementById('');
var error_bairro = document.getElementById('');
var error_municipio = document.getElementById('');
var error_cep = document.getElementById('');
var error_telefone1 = document.getElementById('');
var error_telefone2 = document.getElementById('');
var error_email = document.getElementById('');
//validar
function validar() {
  //campos em branco
  if (username.value == ""){

  }
  if (password.value == ""){

  }
  if (sobrenome.value == ""){

  }
  if (cpf.value == ""){

  }
  if (rg.value == ""){

  }
  if (nacionalidade.value == ""){

  }
  if (nascimento.value == ""){

  }
  if (civil.value == ""){

  }
  if (input_sexo.value == ""){

  }
  if (estado.value == ""){

  }
  if (rua.value == ""){

  }
  if (numero.value == ""){

  }
  if (bairro.value == ""){

  }
  if (municipio.value == ""){

  }
  if (cep.value == ""){

  }
  if (telefone1.value == ""){

  }
  if (telefone2.value == ""){

  }
  if (email.value == ""){

  }
}
