$(document).ready(function() {

  let _containerMenu = $("#fixedmenu");

  $(window).scroll(function() {
    if ($(this).scrollTop() > 60) {
      _containerMenu.addClass("menu-fixo");
    } else {
      _containerMenu.removeClass("menu-fixo");
    }
  });
});
