let slideINICIO = 1;
func_Ofertas(slideINICIO);

function plusDivs(n) {
  func_Ofertas(slideINICIO += n);
}

function func_Ofertas(n) {
  let i;
  let x = document.getElementsByClassName("slideOFERTAS");
  if (n > x.length) slideINICIO = 1
  if (n < 1) slideINICIO = x.length
  for (i = 0; i < x.length; i++) x[i].style.display = "none";
  x[slideINICIO - 1].style.display = "block";
}
