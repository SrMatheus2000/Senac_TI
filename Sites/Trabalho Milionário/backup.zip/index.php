<html>
	<head>

			<?php

			include("include/libsql.php");
			includee("styles");

		?>
		<title>Trabalho Milionário</title>
	</head>
	<body>
		<?php
			if (isset($_POST["deslogar"]) || !isset($_SESSION["id"])) {
				includee("cabecalho");
				includee("menu");
			} else {
				includee("cabecalho_logado");
				includee("menu_logado");
			}

			if(isset($_GET["login"])){
			if (isset($_SESSION["id"])) {
				includee("centro");
			} else {
				includee("login");
			}

			}else if(isset($_GET["cadastro"])){
				includee("cadastro");
			}else if(isset($_GET["produtos"])){
        includee("cadastro_produtos");
      }else if(isset($_GET["carrinho"])){
					includee("carrinho");
      }else{
				includee("centro");
			}
			includee("rodape");
		?>
	</body>
	<?php
		if(isset($_GET["carrinho"])){
			?>
			
			<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php
		}
		else{
		includee("scripts");
	}
	?>
</html>
