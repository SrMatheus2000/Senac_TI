<?php
	function conectarbanco(){
		/*Alterar dados de conexão com banco.*/
		$host = "localhost";
		$banco = "id6664552_trabalhomilionario";
		$usuario = "id6664552_trabalhomilionario";
		$senha = "trabalhomilionario123";
		$porta = "3306";

		/* Não mexer. */
		$conn = new PDO('mysql:host=' . $host . ';port=' . $porta . ';dbname=' . $banco . '', $usuario, $senha);
		return $conn;
	}

	function executasql($sql){
		$conn = conectarbanco();
		$conn->query($sql);
	}

	function selecionadiversosdados($sql){
		$conn = conectarbanco();
		$retorno = $conn->prepare($sql);
		$retorno->execute();
		return $retorno;
	}

	function selecionaumdado($sql){
		$conn = conectarbanco();
		$retorno = $conn->query($sql);
		return $retorno->fetch();
	}

  function includee ($a) {
    if ($a == "styles") {
      include 'include/styles.php';
    } elseif ($a == "cabecalho") {
      include 'include/cabecalho.php';
    } elseif ($a == "cabecalho_logado") {
      include 'include/cabecalho_logado.php';
    } elseif ($a == "menu") {
      include 'include/menu.php';
    } elseif ($a == "menu_logado") {
      include 'include/menu_logado.php';
    } elseif ($a == "login") {
      include 'include/login.php';
    } elseif ($a == "cadastro") {
      include 'include/cadastro.php';
    } elseif ($a == "centro") {
      include 'include/centro.php';
    } elseif ($a == "rodape") {
      include 'include/rodape.php';
    } elseif ($a == "scripts") {
      include 'include/scripts.php';
    } elseif ($a == "carrinho") {
      include 'include/carrinho.php';
    } elseif ($a == "cadastro_produtos") {
      include 'include/cadastro_produtos.php';
    }  // elseif ($_SESSION) {
    //   if ($a == ) {
    //     include 'include/exercicio5.gestor.php';
    //   } elseif ($a == ) {
    //     include 'include/exercicio5.menu.php';
    //   } elseif ($_SESSION["usuariopai"] == 0) {
    //     if ($a == ) {
    //       include 'include/exercicio5.salario.php';
    //     } elseif ($a == ) {
    //       include 'include/exercicio5.despesa.php';
    //     }
    //   } else {
    //     echo "Página não permitida!";
    //   }
    // }
  }

  if (isset($_POST["entrar"])) {
    if ($_POST["login"] != "" && $_POST["senha"] != "" ) {
      $usuario = selecionaumdado(
        "SELECT *
        FROM `cadastro_pessoa`
        WHERE email = '".$_POST["login"]."'
				OR 		CPF   = '".$_POST["login"]."'
        AND   senha = '".$_POST["senha"]."'"
      );
      if($usuario){
        session_start();
        $_SESSION["id"]    = $usuario["id"];
        $_SESSION["email"] = $usuario["email"];
        $_SESSION["nome"]  = $usuario["nome"];
        $_SESSION["senha"] = $usuario["senha"];
      }
    }
  } else {
    session_start();
    if (isset($_POST["deslogar"])) {
      session_destroy();
    }
  }
?>
