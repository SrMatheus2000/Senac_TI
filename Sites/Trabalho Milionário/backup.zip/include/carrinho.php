
<script>
function soma(){
	var quantidade_produto = document.getElementById("quantidade_produto").value;
	var valor_produto = document.getElementById("valor_produto").value;
	var calcula = parseInt(quantidade_produto)*parseInt(valor_produto);
	document.getElementById("subtotal_produto").innerHTML = calcula;
}
</script>

<div class="container" style="min-height:100%; position:relative;">
  <div class="row">
    <legend>
      <div class="col-sm-2">Item(s)</div>
      <div class="col-sm-2">Preço</div>
      <div class="col-sm-3">Quantidade</div>
      <div class="col-sm-2">Subtotal</div>
    </legend>
  </div>
      <div class="row">
        <div class="col-sm-2">
          <img class="produto" style="width:120px; height:120px;" src="img/pepsi_icon.png"/>
        </div>
        <div class="col-sm-2" style="position: relative;">
          <div style="position: absolute; top:50%;" id="valor_produto">100</div>
        </div>
        <div class="col-sm-3" style="position: relative;">
          <div style="position: absolute; top:50%;">
						<div class="qty mt-5">
                        <span class="minus bg-dark">-</span>
                        <input type="number" class="count" name="qty" value="1">
                        <span class="plus bg-dark">+</span>
                    </div>
          	</div>
       </div>

        <div class="col-sm-2" style="position: relative;">
          <div style="position: absolute; top:50%;" id="subtotal_produto"></div>
        </div>
				<div class="col-sm-2">
          <input type="button" value="Finalizar Compra"/>
				</div>
      </div>
  </div>
