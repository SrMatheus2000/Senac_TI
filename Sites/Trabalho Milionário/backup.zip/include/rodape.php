<footer class="footer"
style="background-color: #0badc7;">
	<div
		style="
			background-color: #0badc7;
			height: 8%;
			width: 31%;
			margin: auto;
			padding-left: 10px;
			display: table-cell;">
		<h2>LOGO</h2>
	</div>

	<div
		style="
			background-color: #0badc7;
			height: 8%;
			width: 31%;
			margin: auto;
			display: table-cell;">
		<p>Termos de rodape e tal</p>
	</div>

	<div
		style="
			background-color: #0badc7;
			height: 8%;
			width: 31%;
			margin: auto;
			display: table-cell;">
		<p>mais termos e tal</p>
	</div>

	<div
		style="
			background-color: #0badc7;
			height: 8%;
			width: 31%;
			margin: auto;
			padding-right: 50px;
			display: table-cell;">
		<button class="dropbtn">Fale Conosco</button>
	</div>
</footer>
