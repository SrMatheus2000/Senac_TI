<script src="js/jquery-3.3.1.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/p5.js"></script>
<script src="js/p5.dom.js"></script>
<script src="js/p5.sound.js"></script>
<script src="js/sketch.js"></script>
<script src="js/ofertas.js"></script>
<script src="js/fixedmenu.js"></script>


<!-- <script type="text/javascript" src="js/jquery_recomendados.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-1.8.3.js"></script>
<script type="text/javascript" src="js/jquery.diyslider.js"></script>
<script type="text/javascript" src="http://pioul.fr/ext/jquery-diyslider/jquery.diyslider.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->
