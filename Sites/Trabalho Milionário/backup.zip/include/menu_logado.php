<style>
	.menu_fixo {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    background-color: #0badc7;
    z-index: 1;
	}
</style>

<div class="menu_fixo">
	<div class="container" data-container="menu" style="width: 80%; background-color: #0badc7;">
		<div class="row">
			<div
				style="
					height: 6%;
					display: table-cell;
					float: left;
					width: 40%;">
				<div class="dropdown" style="margin-top: 2%;">
					<button
						onclick="myFunction()"
						class="dropbtn">
						Menu
					</button>
					<div
						id="myDropdown"
						class="dropdown-content">
						<div class="dropdown">
							<button
								onclick="myFunction2()"
								class="dropbtn">
								Teste Subcategoria
							</button>
							<div
								id="myDropdown2"
								class="dropdown-content">
								<a href="#">Link 3</a>
								<a href="#">Link 4</a>
							</div>
						</div>
						<a href="#">Link 1</a>
						<a href="#">Link 2</a>
					</div>
				</div>
			</div>

			<div
				style="
					display: table-cell;
					margin: auto -16%;
					width: 60%;
					float: left;">
				<form method="get" style="margin-top: 2%;">
					<input
						type="search"
						name="pesquisa"
						id="pesquisa"
						placeholder="O que você deseja buscar?"
						style="
							padding: 10px;
							width: 80%;
							border-radius: 5px;
							border: #fff;"/>
					<input
						type="image"
						name="pesquisar"
						id="pesquisar"
						value="Pesquisar"
						src="img/buscar2.png"
						style="
					    position: absolute;
					    margin-left: 5px;
					    width: 35px;"/>
				</form>
			</div>

			<div
				style="
					height: 6%;
					display: table-cell;
					width: 25%;
  				text-align: right;">
				<form method="get" style="margin-top: 2%;">
					<input
						name="desejos"
						id="desejos"
						value="Lista de Desejos"
						type="submit"
						class="dropbtn"/>
					<input
						name="carrinho"
						id="carrinho"
						value="Carrinho"
						type="submit"
						class="dropbtn"/>
				</form>
			</div>
		</div>
	</div>
</div>
