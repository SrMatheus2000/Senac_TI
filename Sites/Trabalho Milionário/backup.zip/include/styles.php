<meta charset="UTF-8"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/bootstrap.css"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/dropdown.css"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/ofertas.css"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/recomendados.css"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/bruno.css"/>

<link
	rel="stylesheet"
	type="text/css"
	href="css/style.css"/>
