





<div class="container">
  <div class="row">

    <div class="col-md-4">

      <?php

     	//$log_user=SelecionaDiversosDados("SELECT * FROM log_user WHERE id_pai = ".$_SESSION["id"]."");

     $log_user=SelecionaDiversosDados("SELECT * FROM logs_produtos ORDER BY data_log desc");

     //fazer botão para mudar ORDER BY

     ?>


     <?php
     $tmp = 0;

     foreach($log_user as $logs){
       if ($tmp++ < 10) {

     /*?>
     <p>	O Usuário <?php print($logs["user"]) ?> entrou na página <?php print($logs["pagina"]) ?> em <?php print($logs["datahora"]) */  //</p><br>

     //  1 = Novo produto   2 = Remover produto   3 = Editar produto
     ?>
     <?php if($logs["tipo_log"] == 1){ ?>
       <p> <?php print($logs["data_log"]); ?> - Item <?php print($logs["id_produto"]) ?> <br>

         O usuário <?php print($logs["id_user"]); ?> adicionou o produto.
       </p>
     <?php }?>

     <?php if($logs["tipo_log"] == 2){ ?>
       <p> <?php print($logs["data_log"]); ?> - Item <?php print($logs["id_produto"]) ?> <br>

         O usuário <?php print($logs["id_user"]); ?> removeu o produto.
       </p>
     <?php }?>


     <?php if($logs["tipo_log"] == 3){ ?>
    <p> <?php print($logs["data_log"]); ?> - Item <?php print($logs["id_produto"]) ?> <br>

      Mudança do campo <?php print($logs["nome_campo"]); ?> de
      <?php print($logs["valor_anterior"]); ?> para <?php print($logs["novo_valor"]); ?>.
      <br>
    </p>
     	<?php
      }
     }

     }
     ?>



    </div>


<div class="col-md-4">
<form method="post" enctype="multipart/form-data">

  <input type="hidden" name="produtos" value="Produtos">
<div class="form-group">
<label for="nome_prod">Nome do Produto</label>
<input class="form-control " name="nome_prod" type="text"/>
</div>

<div class="form-group">
<label for="cod_prod">Código do Produto</label>
<input class="form-control" name="cod_prod" type="text"/>
</div>


<div class="form-group">
  <label for="dsc_prod">Descrição do Produto</label>
<textarea  class="form-control" rows="5" name="dsc_prod" type="text" width="100"></textarea></div><br>

<div class="form-group">
<label for="cat1">Categoria 1</label>
<select name="cat1" class="form-control form-control-sm mx-sm-3 mb-2">
  <option value="cat1">cat1</option>
  <option value="cat2">cat2</option>
  <option value="cat3">cat3</option>
  <option value="cat4">cat4</option>
</select>
</div>

<div class="form-group">
<label for="cat2">Categoria 2 (Opcional)</label>
<select name="cat2" class="form-control form-control-sm mx-sm-3 mb-2">
  <option value="cat1">cat1</option>
  <option value="cat2">cat2</option>
  <option value="cat3">cat3</option>
  <option value="cat4">cat4</option>
</select>
</div>





<div class="form-group">
<label for="marca">Marca</label>
<select name="marca" class="form-control form-control-sm mx-sm-3 mb-2">
  <option value="marca1">marca1</option>
  <option value="marca2">marca2</option>
  <option value="marca3">marca3</option>
  <option value="marca4">marca4</option>
</select>
</div>

<div class="form-group">
<label for="preco_prod">Preço</label>
<input class="form-control" name="preco_prod" type="text"/>
</div>
<button name="prod_cadastro" type="submit" class="btn btn-primary mb-2">Enviar</button>
</div>

<div class="col-md-4">

<div class="carouselExampleControls">
  <div class="slideOFERTAS">
  <div class="form-group">
  <input name="img_prod" type='file' onchange="readURL(this);" />
  <img id="blah" src="#" alt="your image" width="200"/>
  </div>
  <script type="text/javascript">
          function readURL(input) {
              if (input.files && input.files[0]) {
                  var reader = new FileReader();

                  reader.onload = function (e) {
                      $('#blah').attr('src', e.target.result);
                  }

                  reader.readAsDataURL(input.files[0]);
              }
          }
      </script>
</div>

<div class="slideOFERTAS">
<div class="form-group">
<input name="img_prod2" type='file' onchange="readURL2(this);" />
<img id="blah2" src="#" alt="your image" width="200"/>
</div>
<script type="text/javascript">
        function readURL2(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah2').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</div>

<div class="slideOFERTAS">
<div class="form-group">
<input name="img_prod3" type='file' onchange="readURL3(this);" />
<img id="blah3" src="#" alt="your image" width="200"/>
</div>
<script type="text/javascript">
        function readURL3(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah3').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</div>

      <input type="button"  onclick="plusDivs(-1)" class="btn btn-primary mb-2" value="&#10094; Anterior"></input>
    	<input type="button" onclick="plusDivs(1)" class="btn btn-primary mb-2" value="Proximo &#10095;"></input>
    </div>


</div>


</form>




</div>
</div>

<?php
// var_dump(" INSERT INTO produto(nome, codigo, descricao, cat1, cat2, marca, preco, imagem) VALUES
// (
//  '".$_POST["nome_prod"]."',
//  '".$_POST["cod_prod"]."',
//  '".$_POST["dsc_prod"]."',
//  '".$_POST["cat1"]."',
//  '".$_POST["cat2"]."',
//  '".$_POST["marca"]."',
//  '".$_POST["preco"]."',
//  '".$nomecompleto."'
//
// );
//
//
// ");
//
// var_dump($nomecompleto);
// var_dump($_FILES); 

if(isset($_POST["prod_cadastro"])){



$foto = $_FILES["img_prod"];
$pasta = "img/produtos/";
$tipoimagem = strtolower(pathinfo($foto["name"],PATHINFO_EXTENSION));

if ($tipoimagem != "jpg"){
  ?>
  <script>
    alert("Arquivo inválido! Por favor, envie apenas no formato JPG!");
  </script>
  <?php
exit;
}
else if ($_FILES["img_prod"]["size"] > 5000000) {
  ?>
  <script>
    alert("Arquivo muito grande!");
  </script>
  <?php
  exit;
}
else if(move_uploaded_file($foto["tmp_name"], $pasta.$_POST["cod_prod"].".jpg")){

/*  $factory = new \ImageOptimizer\OptimizerFactory();
      $optimizer = $factory->get();

      $filepath = __DIR__ . '/img/produtos/$_POST["cod_prod"].".jpg"';  algum dia será implementado, mas precisamos de um servidor apache antes.

      $optimizer->optimize($filepath);*/

$nomecompleto = $_POST["cod_prod"].".jpg";

$foto = $_FILES["img_prod2"];
$pasta = "img/produtos/";
$tipoimagem = strtolower(pathinfo($foto["name"],PATHINFO_EXTENSION));

if ($tipoimagem != "jpg"){
  ?>
  <script>
    alert("Arquivo inválido! Por favor, envie apenas no formato JPG!");
  </script>
  <?php
exit;
}
else if ($_FILES["img_prod2"]["size"] > 5000000) {
  ?>
  <script>
    alert("Arquivo muito grande!");
  </script>
  <?php
  exit;
}
else if(move_uploaded_file($foto["tmp_name"], $pasta.$_POST["cod_prod"]."_2.jpg")){

/*  $factory = new \ImageOptimizer\OptimizerFactory();
      $optimizer = $factory->get();

      $filepath = __DIR__ . '/img/produtos/$_POST["cod_prod"].".jpg"';  algum dia será implementado, mas precisamos de um servidor apache antes.

      $optimizer->optimize($filepath);*/

$nomecompleto = $_POST["cod_prod"]."_2.jpg";

$foto = $_FILES["img_prod3"];
$pasta = "img/produtos/";
$tipoimagem = strtolower(pathinfo($foto["name"],PATHINFO_EXTENSION));

if ($tipoimagem != "jpg"){
  ?>
  <script>
    alert("Arquivo inválido! Por favor, envie apenas no formato JPG!");
  </script>
  <?php
exit;
}
else if ($_FILES["img_prod3"]["size"] > 5000000) {
  ?>
  <script>
    alert("Arquivo muito grande!");
  </script>
  <?php
  exit;
}
else if(move_uploaded_file($foto["tmp_name"], $pasta.$_POST["cod_prod"]."._3jpg")){

/*  $factory = new \ImageOptimizer\OptimizerFactory();
      $optimizer = $factory->get();

      $filepath = __DIR__ . '/img/produtos/$_POST["cod_prod"].".jpg"';  algum dia será implementado, mas precisamos de um servidor apache antes.

      $optimizer->optimize($filepath);*/

$nomecompleto = $_POST["cod_prod"]."_3.jpg";

}

}

executasql(" INSERT INTO produto(nome, codigo, descricao, cat1, cat2, marca, preco, imagem) VALUES (
 '".$_POST["nome_prod"]."',
 '".$_POST["cod_prod"]."',
 '".$_POST["dsc_prod"]."',
 '".$_POST["cat1"]."',
 '".$_POST["cat2"]."',
 '".$_POST["marca"]."',
 '".$_POST["preco_prod"]."',
 '".$nomecompleto."'

);
");

executasql("INSERT INTO logs_produtos(id_user,data_log,id_produto,tipo_log)
VALUES(
'".$_SESSION["id"]."',
now(),
'".$_POST["cod_prod"]."',
1
);
");

?>

<script>
  alert("Produto registrado com sucesso!");
</script>
<?php
}
}
?>
