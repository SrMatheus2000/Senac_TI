<script type="text/javascript">
document.getElementById("nome").onkeydown = function() {tNome()};
function tNome(){
	 nometeste = document.getElementById("nome").value;
	 len = nometeste.lenght;
	 alert(nometeste);
	if (len > 15 || len < 3){
		alert("funciona");
	}
}

</script>

<div class="container" style="width: 80%;" >
	<div class="row">
		<div
			class="col-md-2"
			style="
				background-color: rgba(100, 0, 0, 0.5);
				height: 1422px;">
			<?php
				include("include/categorias.php");
			?>
		</div>
		<div
			class="col-md-8"
			style="background-color: rgba(0, 100, 0, 0.5);">
			<div class="container-fluid">
				<div class="row">
					<div
						class="col-md-12"
						style="
							background-color: rgba(200, 200, 200, 0.5);
							height: auto;
							padding: 5px;">
						<form method="post" style="text-align: center;">
							<h1>Cadastro</h1>
							<br>
							<h4>Dados Pessoais</h4>
							<input
								type="text"
								name="nome"
								id="nome"
								placeholder="Nome*"
								maxlength="30"
								onkeydown="tNome();"/>
							<br>
							<input
								type="text"
								name="sobrenome"
								id="sobrenome"
								placeholder="Sobrenome*"
								maxlength="30"/>
							<br>
							<input
								type="text"
								name="cpf"
								id="cpf"
								placeholder="CPF*"
								maxlength="14"
								onkeydown="javascript: fMasc( this, mCPF );"/>
							<br>
							<input
								type="text"
								name="rg"
								id="rg"
								placeholder="RG"
								maxlength="10"/>
							<br>
							<input
								type="text"
								name="nacionalidade"
								id="nacionalidade"
								placeholder="Nacionalidade"
								maxlength="30"/>
							<br>
							Data de Nascimento*
							<input
								type="date"
								name="nascimento"
								id="nascimento"
								placeholder="Data de Nascimento*"/>
							<br>
							<select
								name="civil"
								id="civil">
								<option>Estado Civíl*</option>
								<option name="1">Solteiro (a)</option>
								<option name="2">Casado (a)</option>
								<option name="3">Viúvo (a)</option>
								<option name="4">Separado (a) judicialmente</option>
								<option name="5">Divorciado (a)</option>
							</select>
							<br>
							Sexo: *
							<input
								type="radio"
								name="input_sexo"
								id="input_sexo"
								value="1"/>Masculino
							<input
								type="radio"
								name="input_sexo"
								id="input_sexo"
								value="2"/>Feminino
				 			<input
								type="radio"
								name="input_sexo"
								id="input_sexo"
								value="3"/>Outro
							<br>
							<h4>Endereço*</h4>
							<input
								type="text"
								name="estado"
								id="estado"
								placeholder="Estado"
								maxlength="30"/>
							<br>
							<input
								type="text"
								name="rua"
								id="rua"
								placeholder="Rua"
								maxlength="50"/>
							<br>
							<input
								type="text"
								name="numero"
								id="numero"
								placeholder="Número"
								maxlength="5"/>
							<br>
							<input
								type="text"
								name="bairro"
								id="bairro"
								placeholder="Bairro"
								maxlength="50"/>
							<br>
							<input
								type="text"
								name="municipio"
								id="municipio"
								placeholder="Municipio"
								maxlength="50"/>
							<br>
							<input
								type="text"
								name="cep"
								id="cep"
								placeholder="Cep"
								maxlength="10"
								onkeydown="javascript: fMasc( this, mCEP );"/>
							<br>
							<h4>Contato</h4>
							<input
								type="text"
								name="telefone1"
								id="telefone1"
								placeholder="Telefone1*"
								maxlength="14"
								onkeydown="javascript: fMasc( this, mTel );"/>
							<br>
							<input
								type="text"
								name="telefone2"
								id="telefone2"
								placeholder="Telefone2"
								maxlength="14"
								onkeydown="javascript: fMasc( this, mTel );"/>
							<br>
							<input
								type="text"
								name="email"
								id="email"
								placeholder="E-mail*"
								maxlength="50"/>
							<br>
							<input
								type="password"
								name="senha"
								id="senha"
								placeholder="Senha*"
								maxlength="25"/>
							<br>
							<input
								type="password"
								name="senha2"
								id="senha2"
								placeholder="Repita sua Senha*"
								maxlength="25"/>
							<br>
							<input
								type="hidden"
								name="datacadastro"
								 id="datacadastro"/>     <!--inutil? -->
							<br>
							<input
								type="submit"
								value="Cadastrar"
								name="cadastrar"
								id="cadastrar"
								class="btn"/>
							<br>
						</form>

						<?php
							if (isset ($_POST["cadastrar"])  ){
								if ($_POST["nome"]       == "" ||
										$_POST["sobrenome"]  == "" ||
										$_POST["cpf"]        == "" ||
										$_POST["nascimento"] == "" ||
										$_POST["civil"]      == "" ||
										$_POST["input_sexo"] == "" ||
										$_POST["estado"]     == "" ||
										$_POST["rua"]        == "" ||
										$_POST["numero"]     == "" ||
										$_POST["bairro"]     == "" ||
										$_POST["municipio"]  == "" ||
										$_POST["cep"]        == "" ||
										$_POST["telefone1"]  == "" ||
										$_POST["email"]      == "" ||
										$_POST["senha"]      == "" ||
										$_POST["senha2"]     == "" ){

									echo "ERRO: Campos em branco!";

								} else {
									$nome          = $_POST["nome"];
									$sobrenome     = $_POST["sobrenome"];
									$cpf           = $_POST["cpf"];
									$rg            = $_POST["rg"];
									$nacionalidade = $_POST["nacionalidade"];
                  $nascimento    = $_POST["nascimento"];
									$civil         = $_POST["civil"];
									$input_sexo    = $_POST["input_sexo"];
									$estado        = $_POST["estado"];
									$rua           = $_POST["rua"];
									$numero        = $_POST["numero"];
									$bairro        = $_POST["bairro"];
									$municipio     = $_POST["municipio"];
									$cep           = $_POST["cep"];
									$telefone1     = $_POST["telefone1"];
                  $telefone2     = $_POST["telefone2"];
									$email         = $_POST["email"];
									$senha         = $_POST["senha"];
									$senha2        = $_POST["senha2"];

									$data = explode ("-", $nascimento);
									$dia = $data[2];
									$mes = $data[1];
									$ano = $data[0];
?>

									<?php

									//else {
                    executasql (
											"INSERT INTO `cadastro_pessoa` (
	                      nome,
	                      sobrenome,
	                      CPF,
                        RG,
												nacionalidade,
	                      nascimento,
	                      estado_civil,
	                      sexo,
	                      estado,
	                      rua,
	                      numero,
	                      bairro,
	                      municipio,
	                      CEP,
	                      telefone1,
	                      telefone2,
	                      email,
	                      senha,
                        data_cadastro
											) VALUES (
                        '".$nome."',
                        '".$sobrenome."',
                        '".$cpf."',
                        '".$rg."',
												'".$nacionalidade."',
                        '".$nascimento."',
                        '".$civil."',
                        '".$input_sexo."',
                        '".$estado."',
                        '".$rua."',
                        '".$numero."',
                        '".$bairro."',
                        '".$municipio."',
                        '".$cep."',
                        '".$telefone1."',
                        '".$telefone2."',
                        '".$email."',
                        '".$senha."',
                        now()
	                    );"
										);
									//}
								}
							}
						?>
					</div>
				</div>
			</div>
		</div>
		<div
			class="col-md-2"
			style="
				background-color: rgba(0, 0, 100, 0.5);
				height: 1422px;">
			<?php
				include("include/anuncios.php");
			?>
		</div>
	</div>
</div>

<script type="text/javascript">
			function fMasc(objeto,mascara) {
				obj=objeto
				masc=mascara
				setTimeout("fMascEx()",1)
			}
			function fMascEx() {
				obj.value=masc(obj.value)
			}
			function mTel(tel) {
				tel=tel.replace(/\D/g,"")
				tel=tel.replace(/^(\d)/,"($1")
				tel=tel.replace(/(.{3})(\d)/,"$1)$2")
				if(tel.length == 9) {
					tel=tel.replace(/(.{1})$/,"-$1")
				} else if (tel.length == 10) {
					tel=tel.replace(/(.{2})$/,"-$1")
				} else if (tel.length == 11) {
					tel=tel.replace(/(.{3})$/,"-$1")
				} else if (tel.length == 12) {
					tel=tel.replace(/(.{4})$/,"-$1")
				} else if (tel.length > 12) {
					tel=tel.replace(/(.{4})$/,"-$1")
				}
				return tel;
			}
			function mCNPJ(cnpj){
				cnpj=cnpj.replace(/\D/g,"")
				cnpj=cnpj.replace(/^(\d{2})(\d)/,"$1.$2")
				cnpj=cnpj.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3")
				cnpj=cnpj.replace(/\.(\d{3})(\d)/,".$1/$2")
				cnpj=cnpj.replace(/(\d{4})(\d)/,"$1-$2")
				return cnpj
			}
			function mCPF(cpf){
				cpf=cpf.replace(/\D/g,"")
				cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
				cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
				cpf=cpf.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
				return cpf
			}
			function mCEP(cep){
				cep=cep.replace(/\D/g,"")
				cep=cep.replace(/^(\d{2})(\d)/,"$1.$2")
				cep=cep.replace(/\.(\d{3})(\d)/,".$1-$2")
				return cep
			}
			function mNum(num){
				num=num.replace(/\D/g,"")
				return num
			}
		</script>

	<?php //var_dump("INSERT INTO cadastro_pessoa (nome, sobrenome, CPF, nascimento, estado_civil, sexo, senha, estado, rua, numero, bairro, municipio, CEP, telefone1, email, telefone2, RG) VALUES('".$nome."', '".$sobrenome."', '".$cpf."', '".$nascimento."', '".$civil."', '".$input_sexo."', '".$senha."', '".$estado."', '".$rua."', '".$numero."', '".$bairro."', '".$municipio."', '".$cep."', '".$telefone1."', '".$email."', '".$telefone2."', '".$rg."');"); a

  // var_dump("INSERT INTO `cadastro_pessoa` (
  //   nome,
  //   sobrenome,
  //   CPF,
  //   RG,
  //   nacionalidade,
  //   nascimento,
  //   estado_civil,
  //   sexo,
  //   estado,
  //   rua,
  //   numero,
  //   bairro,
  //   municipio,
  //   CEP,
  //   telefone1,
  //   telefone2,
  //   email,
  //   senha,
  //   data_cadastro
  // ) VALUES (
  //   '".$nome."',
  //   '".$sobrenome."',
  //   '".$cpf."',
  //   '".$rg."',
  //   '".$nacionalidade."',
  //   '".$nascimento."',
  //   '".$civil."',
  //   '".$input_sexo."',
  //   '".$estado."',
  //   '".$rua."',
  //   '".$numero."',
  //   '".$bairro."',
  //   '".$municipio."',
  //   '".$cep."',
  //   '".$telefone1."',
  //   '".$telefone2."',
  //   '".$email."',
  //   '".$senha."',
  //   now()
  // );");?>


										<?php
								/*
								if (strlen($nome) > 15 ||
										strlen($nome) < 3  ){
									echo "ERRO: Campo Nome inválido!";
								}
										if (strlen($sobrenome) > 30 ||
														strlen($sobrenome) < 3  ){
											echo "ERRO: Campo Sobrenome inválido!";
										}

										if (strlen($cpf) > 14 ||
										  			strlen($cpf) < 14 ){
											echo "ERRO: Campo CPF inválido!";
										}

										if (strlen($rg)  != 10) {
											echo "ERRO: Campo RG inválido!";
										}

										if (strlen ($nacionalidade) < 3) {
											echo "ERRO: Campo Nacionalidade inválido!";
										}

	                  if ($ano > (date("Y")-18)  ||
	                          $ano < (date("Y")-125) ){
	                    echo "ERRO: Campo Data inválido!";
	                  }

										if (strlen($telefone1) < 13 || strlen($telefone1) > 14) {
											echo "ERRO: Telefone inválido!";
										}

										if ($telefone2 != "") {
											if (strlen($telefone2) < 13 || strlen($telefone2) > 14) {
												echo "ERRO: Telefone inválido!";
											}
										}
										if (strlen ($senha) < 6 || strlen ($senha) > 25) {
									 	echo "ERRO: A senha deve ter entre 6 e 25 caracteres!";
									 }

										if ($senha != $senha2) {
											echo "ERRO: As senhas devem ser iguais!";
										}
	*/
										?>
