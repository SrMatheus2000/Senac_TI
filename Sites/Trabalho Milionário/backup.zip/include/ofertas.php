<div class="carouselExampleControls">
	<img class="slideOFERTAS" src="img/oferta.png" style="width:100%"/>
	<img class="slideOFERTAS" src="img/pepsi.png" style="width:100%"/>
	<img class="slideOFERTAS" src="img/x.png" style="width:100%"/>

	<button class="btnEsquerdo" onclick="plusDivs(-1)">&#10094; Anterior</button>
	<button class="btnDireito" onclick="plusDivs(1)">Proximo &#10095;</button>
</div>
