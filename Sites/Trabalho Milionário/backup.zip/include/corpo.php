<h1>Corpo do Site (itens padrao)</h1>

<div style="text-align: center;">
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<br>                             
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<br>                            
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
	<button type="button" class="btn MaisProcurados">
		<a href="#">
			<img class="imgPRODUTO" src="img/pepsi_icon.png"/>
			<p class="TITULO">Refrigerante Pepsi</p>
			<p class="PRECO">R$ 0,00</p>
			<p class="CARRINHO_ADD">ADICIONAR AO CARRINHO</p>
		</a>
	</button>
</div>