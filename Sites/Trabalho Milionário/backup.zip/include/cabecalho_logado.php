<div style="background-color: #0badc7" class="menu-cabecalho">
	<div class="container" style="width: 80%;">
		<div class="row" style="margin-top: 0.5%;">
				<div
					class="pull-left"
					style="height: 6%;">
					<button>
						<a
							href="/"
							style="
								color: #FFF;
								font-size: 36px;
								background: transparent no-repeat;
	  						border: none;
								text-decoration: none; ">
							Trabalho Milionário
						</a>
					</button>
				</div>
			<form method="get" >
				<div
					class="pull-right"
					style="
						height: 6%;">
            <input
  						name="produtos"
  						id="produtos"
  						value="Produtos"
  						type="submit"
  						class="dropbtn"
							style="margin-left: 2;"/>
        </div>
				<div
					class="pull-right"
					style="
						height: 6%;">
					</form>
					<form method="post" >
            <input
  						name="deslogar"
  						id="deslogar"
  						value="Deslogar"
  						type="submit"
  						class="dropbtn"
							style="margin-right: 2;"/>
        </div>
			</form>
		</div>
	</div>
</div>


<!-- <div style="background-color: #0badc7" class="menu-cabecalho">
	<div class="container" style="width: 80%;">
		<div class="row" style="margin-top: 0.5%;">

			<div class="pull-left" style="height: 6%;">
				<button>
					<a href="/" style="
							color: #FFF;
							font-size: 36px;
							background: transparent no-repeat;
  						border: none;
							text-decoration: none; ">
						Trabalho Milionário
					</a>
				</button>
			</div>

			<div
				class="dropdown"
				style="margin-top: 2%;">

				<button
					onclick="myunction()"
					class="dropbtn">
					Menu
				</button>

				<div
					id="myDropdown"
					class="dropdown-content">
					<div class="dropdown">
						<form
							method="post"
							enctype="multipart/form-data">
							<div
								class="dropdown"
								style="height: 6%;">
								<input
									name="imagem"
									id="imagem"
									value="imagem"
									type="file"
									class="dropbtn">
								<input
									name="salvar"
									id="salvar"
									value="OK"
									type="submit"
									class="dropbtn">
								<br>
								<br>
							</div>
						</form>
					</div>
				</div>

			</div>

		</div>
	</div>
</div> -->
