<div class="container" style="width: 80%;" >
	<div class="row">
		<div
			class="col-md-2"
			style="
				background-color: rgba(100, 0, 0, 0.5);
				height: 1422px;">
			<?php
				include("include/categorias.php");
			?>
		</div>
		<div
			class="col-md-8"
			style="background-color: rgba(0, 100, 0, 0.5);">
			<div class="container-fluid">
				<div class="row">
					<div
						class="col-md-12"
						style="
							background-color: rgba(200, 200, 200, 0.5);
							height: auto;
							padding: 5px;">
            <form
              method="post"
              style="text-align: center;">
              <h1>Login</h1>
              <br>
              <input
        				type="text"
        				name="login"
        				id="login"
        				placeholder="Email ou CPF"/>
        			<br>
        			<input
        				type="password"
        				name="senha"
        				id="senha"
        				placeholder="Senha"/>
        			<br>
        			<input
        				type="submit"
        				value="Entrar"
        				name="entrar"
        				id="entrar"
                class="btn">
              <br>
            </form>
						<?php
							if (isset($_POST["entrar"])) {
								if ($_POST["login"] != "" && $_POST["senha"] != "" ) {
									if(isset($_SESSION)){
										echo "<center>Usuário \"Logado\"!</center>";
									} else {
										echo "<center>Usuário ou senha incorretos!</center>";
									}
								} else {
									echo "<center>Digite todos os seus dados!</center>";
								}
							}
						?>
					</div>
				</div>
			</div>
		</div>
		<div
			class="col-md-2"
			style="
				background-color: rgba(0, 0, 100, 0.5);
				height: 1422px;">
			<?php
				include("include/anuncios.php");
			?>
		</div>
	</div>
</div>
