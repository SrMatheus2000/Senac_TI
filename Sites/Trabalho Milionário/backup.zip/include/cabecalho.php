<div style="background-color: #0badc7" class="menu-cabecalho">
	<div class="container" style="width: 80%;">
		<div class="row" style="margin-top: 0.5%;">
				<div
					class="pull-left"
					style="height: 6%;">
					<button>
						<a
							href="/"
							style="
								color: #FFF;
								font-size: 36px;
								background: transparent no-repeat;
	  						border: none;
								text-decoration: none; ">
							Trabalho Milionário
						</a>
					</button>
				</div>
			<form method="get" >
				<div
					class="pull-right"
					style="
						height: 6%;">
					<input
						name="login"
						id="login"
						value="Login"
						type="submit"
						class="dropbtn"/>
					<input
						name="cadastro"
						id="cadastro"
						value="Cadastro"
						type="submit"
						class="dropbtn"/>
          <input
						name="produtos"
						id="produtos"
						value="Produtos"
						type="submit"
						class="dropbtn"/>
        </div>
			</form>
		</div>
	</div>
</div>
