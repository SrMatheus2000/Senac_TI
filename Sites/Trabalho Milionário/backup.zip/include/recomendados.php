<div class="M_Proc">
  <p><b>MAIS PROCURADOS</b></p>

  <div class="slide">

  <div class="MaisProcurados" id="about">
    <div class="imgPRODUTO">
      <a href="#"><img src="img/pepsi_icon.png"/></a>
    </div>
    <div class="TITULO">
      <a href="#">Refrigerante Pepsi</a>
    </div>
    <div class="PRECO">
      <a href="#">R$ 0,00</a>
    </div>
    <a href="#"><div class="CARRINHO_ADD">
      ADICIONE AO CARRINHO
    </div></a>
  </div>

  <div class="MaisProcurados" id="artists">
    <div class="imgPRODUTO">
      <a href="#"><img src="img/coca_lata.png"/></a>
    </div>
    <div class="TITULO">
      <a href="#">Refrigerante Pepsi</a>
    </div>
    <div class="PRECO">
      <a href="#">R$ 0,00</a>
    </div>
    <a href="#"><div class="CARRINHO_ADD">
      ADICIONE AO CARRINHO
    </div></a>
  </div>


    <button class="btnEsquerdo" id="for_a">&#10094; Anterior</button>
  <button class="btnDireito" id="for_b">Proximo &#10095;</button>
  </div>

</div>
